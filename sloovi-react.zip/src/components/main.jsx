import React from "react";
import "./main.css";
import Task from "./task";

function Main(){
    return (
        <div className="Tasks">
            <div className="main">
                <p className="name">TASKS</p>
                <p className="new">+</p>
            </div>
            <Task></Task>
        </div>
    );
}

export default Main;