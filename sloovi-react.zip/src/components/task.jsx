import React from "react";
import './task.css';


function Task(){
    return (<div className="task">
        <p>Task Discription</p>
        <div class="input-container">
            <i class="fa fa-user icon"></i>
            <input class="input__field" type="text" placeholder="Discription" name="usrnm"/>
        </div>
            
        <div className="date__time">
            <div className="date">
                <p>Date</p>
                <input type="date" className="dt"/>
            </div>
            
            <div className="time">
                <p>Time</p>
                <input type="time" className="dt"/>
            </div>
        </div>
        <div className="assign__user">
                <p>Assign User</p>
                <input list="browsers" name="myBrowser" class="input__field" />
                <datalist id="browsers">
                <option value="Chrome"/>
                <option value="Firefox"/>
                <option value="Internet Explorer"/>
                <option value="Opera"/>
                <option value="Safari"/>
                <option value="Microsoft Edge"/>
                </datalist>
        </div>
        <div className="btns">
            <button className="cancel">Cancel</button>
            <button className="save">Save</button>
        </div>
    </div>);
}

export default Task;